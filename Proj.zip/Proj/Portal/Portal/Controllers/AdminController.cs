﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Portal.Data;
using Portal.Models;
using Portal.Models.ViewModel;

namespace Portal.Controllers
{
    public class AdminController : Controller
    {
        private readonly ApplicationContext context;
        public AdminController(ApplicationContext context)
        {
            this.context = context;

        }

        public IActionResult AdminPage()
        {
            return View();
        }
        public IActionResult Index()
        {
            var Admin1 = new Admin()
            {

                FullName = "M.Aslam",
                UserName = "Aslam",
                Email = "Aslam123@gmail.com",
                Password = "12345"
            };
            context.Admins.Add(Admin1);
            context.SaveChanges();
            return RedirectToAction("Login");
        }
        public IActionResult Login()//Get Method
        {
            return View();
        }
        [HttpPost]
        public IActionResult Login(LoginSignUpViewModel Admin1)//Get Method
        {
            if (ModelState.IsValid)
            {
                var data = context.Admins.Where(e => e.Email == Admin1.Email).SingleOrDefault();
                if (data != null)
                {
                    bool isValid = (data.Email == Admin1.Email && data.Password == Admin1.Password);
                    if (isValid)
                    {
                        var identity = new ClaimsIdentity(new[] { new Claim(ClaimTypes.Email, Admin1.Email) },
                            CookieAuthenticationDefaults.AuthenticationScheme);
                        var principal = new ClaimsPrincipal(identity);
                        HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);
                        HttpContext.Session.SetString("Email", Admin1.Email);
                        return RedirectToAction("Index", "Home");
                    }
                    else
                    {
                        TempData["errorMessage"] = "Invalid Password";
                        return View();
                    }
                }
                else
                {
                    TempData["errorMessage"] = "UserName Not found";
                    return View();
                }
            }
            else
            {
                return View(Admin1);
            }
        }
    }
}