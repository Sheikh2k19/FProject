﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Portal.Data;
using Portal.Models;
using Portal.Models.ViewModel;

namespace Portal.Controllers
{
    public class UserController : Controller
    {
        private readonly ApplicationContext context;

        public UserController(ApplicationContext context)
        {
            this.context = context;

        }

         public IActionResult Index()
        {
            var result = context.Users.ToList();
            return View(result);
        }
        [HttpPost]
        public IActionResult CreateInstructor(SignUpViewModel model)
        {
            if(ModelState.IsValid)
            {
                var user1 = new User()
                {
                    Id=model.Id,
                    FullName=model.FullName,
                    UserName=model.UserName,
                    Email=model.Email,
                    Password=model.Password
                };
                context.Users.Add(user1);
                context.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {
                TempData["error"] = "Empty Field Canot submit";
                return View(model);
            }
            
        }

    }
}