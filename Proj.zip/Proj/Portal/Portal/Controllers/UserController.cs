﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Portal.Data;
using Portal.Models;
using Portal.Models.ViewModel;

namespace Portal.Controllers
{
    public class UserController : Controller
    {
        private readonly ApplicationContext context;

        public UserController(ApplicationContext context)
        {
            this.context = context;

        }

         public IActionResult Index()
        {
            var result = context.Users.ToList();
            return View(result);
        }

        public IActionResult SignUp()//Get Method
        {
            return View();
        }
        [HttpPost]
        public IActionResult SignUp(SignUpViewModel model)
        {
            if (ModelState.IsValid)
            {
                var user1 = new User()
                {
                   
                    FullName = model.FullName,
                    UserName = model.UserName,
                    Email = model.Email,
                    Password = model.Password
                };
                context.Users.Add(user1);
                context.SaveChanges();
                return RedirectToAction("Login");
            }
            else
            {
                TempData["error"] = "Empty Field Canot submit";
                return View();
            }
        }
        public IActionResult Login()//Get Method
        {
            return View();
        }
        [HttpPost]
        public IActionResult Login(LoginSignUpViewModel model)//Get Method
        {
            if (ModelState.IsValid)
            {
                var data = context.Users.Where(e => e.Email == model.Email).SingleOrDefault();
                if (data != null)
                {
                    bool isValid = (data.Email == model.Email && data.Password == model.Password);
                    if (isValid)
                    {
                        var identity = new ClaimsIdentity(new[] { new Claim(ClaimTypes.Email, model.Email) },
                            CookieAuthenticationDefaults.AuthenticationScheme);
                        var principal = new ClaimsPrincipal(identity);
                        HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);
                        HttpContext.Session.SetString("Email", model.Email);
                        return RedirectToAction("Index", "Home");
                    }
                    else
                    {
                        TempData["errorMessage"] = "Invalid Password";
                        return View();
                    }
                }
                else
                {
                    TempData["errorMessage"] = "UserName Not found";
                    return View();
                }
            }
            else
            {
                return View(model);
            }
        }

        public IActionResult LogOut()//Get Method
        {
            HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Login", " User");
        }
    }
    }

