﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Portal.Models.ViewModel
{
    public class SignUpViewModel
    {
        public int Id { get; set; }
        [Required(ErrorMessage="Please Enter Id") ]
        public string FullName { get; set; }
        [Required(ErrorMessage = "Please Enter Full Name")]
        public string UserName { get; set; }
        [Required(ErrorMessage = "Please Enter User Name")]
        public string Email { get; set; }
        [Required(ErrorMessage = "Please Enter Email")]

        public string Password { get; set; }
        [Required(ErrorMessage = "Please Enter Password")]

        public string ConfirmPassword {get; set;}
        [Required(ErrorMessage = "Please Enter Password")]
        public bool IsActive { get; set; }

        public bool IsRemember { get; set; }



    }
}
